import pandas as pd
df = pd.read_csv('content/sum_content_destination_copy.txt',index_col=0)
db = df.sample(frac=1)
db.to_csv('./sum_content_desination_shuffle')


# df.sample(frac=1).reset_index(drop=True)

#shuffle是不是确定是行的乱序  