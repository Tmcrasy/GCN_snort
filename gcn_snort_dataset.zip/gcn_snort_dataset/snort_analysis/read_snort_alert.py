import re
import pandas as pd

msg_strings = []
ip_source_address_string = []
source_port_string = []
ip_destination_address_string = []
destination_port_string = []
msg = []

with open("/Users/lianghuaxiong/Downloads/GCN/gcn_snort_dataset/snort_analysis/alert.txt") as f:
    lines = f.readlines()
    for line in lines:
        msg = re.findall(r'].[A-Za-z]+.+[A-Za-z]',line)
        ip_address_port_string = re.match(r'([0-9:./-]+)\s+.*?(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})\s+->\s+(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}):(\d{1,5})',line)
        # Classification = re.match(r'\[C.+?\]',line)   这里是添加classifition的，但考虑表标签泄露，所以这里就没有写进去，关键是代码编写也难，目前的baseline是不需要的
        # if msg or Classification:
        #     msg_strings.append(str(msg)+str(Classification))
        if msg:
            msg_strings.append(msg)
        if ip_address_port_string:
            ip_source_address_string.append(ip_address_port_string.group(2))
            source_port_string.append(ip_address_port_string.group(3))
            ip_destination_address_string.append(ip_address_port_string.group(4))
            destination_port_string.append(ip_address_port_string.group(5))
'''这个msg_string后期还要数据处理'''
'''列表没有split(),但是可以切片啊'''
for msg_string in msg_strings:
    msg.append(msg_string[0][2:])










